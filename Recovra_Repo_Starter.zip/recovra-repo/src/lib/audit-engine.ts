export type AuditInput = {
  carrier: string;
  invoiceNumber: string;
  invoiceTotal: number;
  expectedTotal: number;
  duplicateDetention?: number;
  questionableFuel?: number;
  weightTierDifference?: number;
  notes?: string;
};

export type AuditFinding = {
  code: string;
  title: string;
  explanation: string;
  amount: number;
  confidence: "high" | "medium" | "review";
};

export type AuditResult = {
  carrier: string;
  invoiceNumber: string;
  invoiceTotal: number;
  expectedTotal: number;
  potentialOvercharge: number;
  findings: AuditFinding[];
  disputeDraft: string;
};

function dollars(value: number) {
  return `$${value.toFixed(2)}`;
}

export function runAudit(input: AuditInput): AuditResult {
  const invoiceTotal = Math.max(0, Number(input.invoiceTotal) || 0);
  const expectedTotal = Math.max(0, Number(input.expectedTotal) || 0);
  const rawDifference = Math.max(0, invoiceTotal - expectedTotal);

  const findings: AuditFinding[] = [];

  const detention = Math.max(0, Number(input.duplicateDetention) || 0);
  const fuel = Math.max(0, Number(input.questionableFuel) || 0);
  const weight = Math.max(0, Number(input.weightTierDifference) || 0);

  if (detention > 0) {
    findings.push({
      code: "DUPLICATE_DETENTION",
      title: "Possible duplicate detention",
      explanation: "A detention amount was supplied for review as a potentially duplicated or unsupported charge.",
      amount: detention,
      confidence: "review"
    });
  }

  if (fuel > 0) {
    findings.push({
      code: "FUEL_SURCHARGE_MISMATCH",
      title: "Possible fuel surcharge mismatch",
      explanation: "The billed fuel component appears higher than the expected amount entered for this audit.",
      amount: fuel,
      confidence: "medium"
    });
  }

  if (weight > 0) {
    findings.push({
      code: "WEIGHT_TIER_MISMATCH",
      title: "Possible weight-tier mismatch",
      explanation: "The entered expected weight-tier pricing indicates a possible pricing difference.",
      amount: weight,
      confidence: "medium"
    });
  }

  const itemized = findings.reduce((sum, f) => sum + f.amount, 0);
  const potentialOvercharge = Math.max(rawDifference, itemized);

  if (potentialOvercharge > 0 && findings.length === 0) {
    findings.push({
      code: "TOTAL_RATE_MISMATCH",
      title: "Invoice total exceeds expected total",
      explanation: `The invoice total exceeds the expected total by ${dollars(rawDifference)}. Contract and shipment evidence should be reviewed before disputing.`,
      amount: rawDifference,
      confidence: "high"
    });
  }

  const disputeDraft =
`Subject: Request for review of freight invoice ${input.invoiceNumber}

Hello,

We are requesting a review of freight invoice ${input.invoiceNumber} from ${input.carrier}.

Billed total: ${dollars(invoiceTotal)}
Expected total entered in Recovra: ${dollars(expectedTotal)}
Potential amount requiring review: ${dollars(potentialOvercharge)}

${findings.map((f) => `- ${f.title}: ${dollars(f.amount)} — ${f.explanation}`).join("\n") || "- No discrepancy identified in the entered totals."}

Please review the charges against the applicable rate agreement and shipment records and provide supporting detail or a corrected invoice where appropriate.

Thank you.`;

  return {
    carrier: input.carrier,
    invoiceNumber: input.invoiceNumber,
    invoiceTotal,
    expectedTotal,
    potentialOvercharge,
    findings,
    disputeDraft
  };
}
