export const demoAudits = [
  {
    invoice: "INV-10482",
    carrier: "Northline Freight",
    amount: 4820,
    savings: 525,
    status: "Review"
  },
  {
    invoice: "INV-10477",
    carrier: "Metro LTL",
    amount: 2675,
    savings: 184,
    status: "Open"
  },
  {
    invoice: "INV-10463",
    carrier: "Northline Freight",
    amount: 3180,
    savings: 310,
    status: "Won"
  },
  {
    invoice: "INV-10451",
    carrier: "RapidHaul",
    amount: 1290,
    savings: 0,
    status: "Closed"
  }
];
