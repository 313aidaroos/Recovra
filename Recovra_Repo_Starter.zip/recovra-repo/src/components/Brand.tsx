import Image from "next/image";

export function Brand({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return <span className="brand">Recovra</span>;
  }

  return (
    <span className="brand">
      <Image
        src="/recovra-logo.png"
        alt="Recovra"
        width={420}
        height={315}
        priority
      />
    </span>
  );
}
