import Link from "next/link";
import { Brand } from "@/components/Brand";

export function DashboardShell({
  children,
  active
}: {
  children: React.ReactNode;
  active: "dashboard" | "audit" | "recoveries" | "contracts";
}) {
  const items = [
    ["dashboard", "Dashboard", "/dashboard"],
    ["audit", "Audit Center", "/audit"],
    ["recoveries", "Recovery Center", "/recoveries"],
    ["contracts", "Contracts", "/contracts"]
  ] as const;

  return (
    <div className="dashboard-shell">
      <aside className="sidebar">
        <Link href="/"><Brand compact /></Link>
        <div style={{fontSize:12,color:"#8da5b6",marginTop:5}}>LOGISTICS RECOVERY</div>
        <nav className="side-nav">
          {items.map(([id, label, href]) => (
            <Link key={id} href={href} className={`side-link ${active === id ? "active" : ""}`}>
              {label}
            </Link>
          ))}
        </nav>
        <div style={{marginTop:28,padding:12,border:"1px solid rgba(255,255,255,.12)",borderRadius:12,color:"#b9c9d5",fontSize:13,lineHeight:1.5}}>
          Demo mode is enabled by default. Connect Supabase to activate real organizations and document storage.
        </div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
