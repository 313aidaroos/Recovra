import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { demoAudits } from "@/lib/demo-data";

export default function DashboardPage() {
  const spend = demoAudits.reduce((sum, a) => sum + a.amount, 0);
  const savings = demoAudits.reduce((sum, a) => sum + a.savings, 0);

  return (
    <DashboardShell active="dashboard">
      <div className="page-head">
        <div>
          <h1>Control center</h1>
          <div className="muted">A clear view of freight spend and recovery opportunities.</div>
        </div>
        <Link href="/audit" className="btn btn-primary">New audit</Link>
      </div>

      <div className="stats">
        <div className="stat"><span>Spend audited</span><strong>${spend.toLocaleString()}</strong></div>
        <div className="stat green"><span>Potential savings</span><strong>${savings.toLocaleString()}</strong></div>
        <div className="stat green"><span>Recovered</span><strong>$310</strong></div>
        <div className="stat"><span>Open recoveries</span><strong>2</strong></div>
      </div>

      <section className="panel">
        <div style={{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center"}}>
          <div>
            <h3>Recent audits</h3>
            <div className="muted">Demo records showing the intended workflow.</div>
          </div>
          <Link href="/audit" className="btn btn-secondary">Run audit</Link>
        </div>
        <div className="table-wrap" style={{marginTop:16}}>
          <table>
            <thead>
              <tr><th>Invoice</th><th>Carrier</th><th>Amount</th><th>Potential savings</th><th>Status</th></tr>
            </thead>
            <tbody>
              {demoAudits.map((a) => (
                <tr key={a.invoice}>
                  <td><strong>{a.invoice}</strong></td>
                  <td>{a.carrier}</td>
                  <td>${a.amount.toLocaleString()}</td>
                  <td style={{color:a.savings ? "#087c50" : undefined,fontWeight:800}}>${a.savings.toLocaleString()}</td>
                  <td><span className={`badge ${a.status.toLowerCase() === "won" ? "won" : a.status.toLowerCase() === "review" ? "review" : "open"}`}>{a.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <div className="grid-3">
        <div className="card">
          <div className="iconbox">$</div>
          <h3>Top issue</h3>
          <p>Accessorial charges are producing the largest demo recovery opportunity.</p>
        </div>
        <div className="card">
          <div className="iconbox">↗</div>
          <h3>Carrier watch</h3>
          <p>Northline Freight represents the largest savings opportunity in the sample set.</p>
        </div>
        <div className="card">
          <div className="iconbox">✓</div>
          <h3>Next action</h3>
          <p>Review the open findings, then generate the evidence-backed dispute draft.</p>
        </div>
      </div>
    </DashboardShell>
  );
}
