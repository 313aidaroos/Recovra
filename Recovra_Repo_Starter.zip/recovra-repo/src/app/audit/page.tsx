import { DashboardShell } from "@/components/DashboardShell";
import AuditClient from "./AuditClient";

export default function AuditPage() {
  return (
    <DashboardShell active="audit">
      <div className="page-head">
        <div>
          <h1>Audit center</h1>
          <div className="muted">Compare billed freight costs with what you expected to pay.</div>
        </div>
      </div>
      <AuditClient />
    </DashboardShell>
  );
}
