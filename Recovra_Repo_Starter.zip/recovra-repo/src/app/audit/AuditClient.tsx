"use client";

import { FormEvent, useState } from "react";
import type { AuditResult } from "@/lib/audit-engine";

const initial = {
  carrier: "Northline Freight",
  invoiceNumber: "INV-10482",
  invoiceTotal: "4820",
  expectedTotal: "4295",
  duplicateDetention: "150",
  questionableFuel: "117",
  weightTierDifference: "258",
  notes: ""
};

export default function AuditClient() {
  const [form, setForm] = useState(initial);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function set(name: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [name]: value }));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          invoiceTotal: Number(form.invoiceTotal),
          expectedTotal: Number(form.expectedTotal),
          duplicateDetention: Number(form.duplicateDetention || 0),
          questionableFuel: Number(form.questionableFuel || 0),
          weightTierDifference: Number(form.weightTierDifference || 0)
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Audit failed");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Audit failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <section className="panel">
        <div className="notice">
          This is the repo's functional demo engine. Production mode will replace manual values with extracted invoice, contract and shipment data.
        </div>

        <form className="form-grid" onSubmit={submit}>
          <div className="field">
            <label>Carrier</label>
            <input value={form.carrier} onChange={(e) => set("carrier", e.target.value)} />
          </div>
          <div className="field">
            <label>Invoice number</label>
            <input value={form.invoiceNumber} onChange={(e) => set("invoiceNumber", e.target.value)} />
          </div>
          <div className="field">
            <label>Invoice total</label>
            <input type="number" step="0.01" value={form.invoiceTotal} onChange={(e) => set("invoiceTotal", e.target.value)} />
          </div>
          <div className="field">
            <label>Expected total</label>
            <input type="number" step="0.01" value={form.expectedTotal} onChange={(e) => set("expectedTotal", e.target.value)} />
          </div>
          <div className="field">
            <label>Possible duplicate detention</label>
            <input type="number" step="0.01" value={form.duplicateDetention} onChange={(e) => set("duplicateDetention", e.target.value)} />
          </div>
          <div className="field">
            <label>Possible fuel mismatch</label>
            <input type="number" step="0.01" value={form.questionableFuel} onChange={(e) => set("questionableFuel", e.target.value)} />
          </div>
          <div className="field">
            <label>Possible weight-tier difference</label>
            <input type="number" step="0.01" value={form.weightTierDifference} onChange={(e) => set("weightTierDifference", e.target.value)} />
          </div>
          <div className="field">
            <label>Demo document upload</label>
            <input type="file" accept=".pdf,.png,.jpg,.jpeg,.csv" />
          </div>
          <div className="field full">
            <label>Notes</label>
            <textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Optional notes..." />
          </div>
          <div className="full">
            <button className="btn btn-primary" disabled={loading}>
              {loading ? "Auditing..." : "Run Recovra audit"}
            </button>
          </div>
        </form>
      </section>

      {error && <div className="notice error">{error}</div>}

      {result && (
        <section className="panel">
          <h3>Audit result</h3>
          <div className="result-summary">
            <div className="result-box"><span className="muted">Invoice total</span><strong>${result.invoiceTotal.toFixed(2)}</strong></div>
            <div className="result-box"><span className="muted">Expected</span><strong>${result.expectedTotal.toFixed(2)}</strong></div>
            <div className="result-box savings"><span>Potential overcharge</span><strong>${result.potentialOvercharge.toFixed(2)}</strong></div>
          </div>

          <h3>Findings</h3>
          {result.findings.length === 0 ? (
            <p className="muted">No overcharge was identified from the entered values.</p>
          ) : result.findings.map((f) => (
            <div className="finding" key={f.code}>
              <span className="code">{f.code} · {f.confidence}</span>
              <strong style={{display:"block",marginTop:4}}>{f.title} — ${f.amount.toFixed(2)}</strong>
              <p>{f.explanation}</p>
            </div>
          ))}

          <h3 style={{marginTop:24}}>Recovery draft</h3>
          <div className="dispute">{result.disputeDraft}</div>
        </section>
      )}
    </>
  );
}
