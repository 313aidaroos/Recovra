import { NextResponse } from "next/server";
import { runAudit, type AuditInput } from "@/lib/audit-engine";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Partial<AuditInput>;

    if (!body.carrier || !body.invoiceNumber) {
      return NextResponse.json(
        { error: "carrier and invoiceNumber are required" },
        { status: 400 }
      );
    }

    const invoiceTotal = Number(body.invoiceTotal);
    const expectedTotal = Number(body.expectedTotal);

    if (!Number.isFinite(invoiceTotal) || !Number.isFinite(expectedTotal)) {
      return NextResponse.json(
        { error: "invoiceTotal and expectedTotal must be valid numbers" },
        { status: 400 }
      );
    }

    return NextResponse.json(
      runAudit({
        carrier: body.carrier,
        invoiceNumber: body.invoiceNumber,
        invoiceTotal,
        expectedTotal,
        duplicateDetention: Number(body.duplicateDetention || 0),
        questionableFuel: Number(body.questionableFuel || 0),
        weightTierDifference: Number(body.weightTierDifference || 0),
        notes: body.notes || ""
      })
    );
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}
