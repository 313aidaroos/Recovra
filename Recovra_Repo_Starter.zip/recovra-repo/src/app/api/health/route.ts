import { NextResponse } from "next/server";

export function GET() {
  return NextResponse.json({
    ok: true,
    app: "Recovra",
    mode: process.env.NEXT_PUBLIC_DEMO_MODE === "false" ? "production" : "demo"
  });
}
