import Link from "next/link";
import { Brand } from "@/components/Brand";

const benefits = [
  {
    icon: "$",
    title: "Find overcharges",
    text: "Compare billed freight charges against the amount your business expected to pay."
  },
  {
    icon: "✓",
    title: "Recover savings",
    text: "Turn supported findings into organized recovery and dispute workflows."
  },
  {
    icon: "↗",
    title: "Control logistics",
    text: "See where freight spend, fees and recurring carrier issues are actually coming from."
  }
];

export default function Home() {
  return (
    <>
      <header className="topbar">
        <div className="container nav">
          <Brand />
          <nav className="navlinks">
            <a href="#how">How it works</a>
            <a href="#vision">Vision</a>
            <Link className="btn btn-primary" href="/dashboard">Open demo</Link>
          </nav>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="container hero-grid">
            <div>
              <span className="kicker">Freight cost recovery</span>
              <h1>Stop paying freight charges you should not owe.</h1>
              <p className="lead">
                Recovra audits freight costs against expected rates, surfaces possible
                overcharges and gives your team a recovery workflow without forcing
                you to replace your entire logistics stack.
              </p>
              <div className="hero-actions">
                <Link className="btn btn-primary" href="/audit">Run a demo audit</Link>
                <Link className="btn btn-secondary" href="/dashboard">View dashboard</Link>
              </div>
            </div>

            <div className="mock">
              <div style={{fontWeight: 900, marginBottom: 14}}>RECOVRA AUDIT</div>
              <div className="inner">
                <div className="metric-row">
                  <div className="metric-mini"><small>Invoice</small><strong>$4,820</strong></div>
                  <div className="metric-mini"><small>Expected</small><strong>$4,295</strong></div>
                  <div className="metric-mini"><small>Potential</small><strong style={{color:"#087c50"}}>$525</strong></div>
                </div>
                <div className="flag">
                  <strong>Potential overcharge found</strong>
                  <div style={{marginTop:6, color:"#6d5a30"}}>Duplicate detention + rate mismatch require review.</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="how" className="section">
          <div className="container">
            <div className="section-head">
              <span className="kicker">The simple wedge</span>
              <h2>Audit first. Recover second.</h2>
              <p className="lead">
                The first version does one job extremely clearly: show a business where freight costs may not match its expected rates.
              </p>
            </div>
            <div className="grid-3">
              {benefits.map((b) => (
                <div className="card" key={b.title}>
                  <div className="iconbox">{b.icon}</div>
                  <h3>{b.title}</h3>
                  <p>{b.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="vision" className="section" style={{background:"#fff"}}>
          <div className="container hero-grid">
            <div>
              <span className="kicker">Long-term vision</span>
              <h2>Your logistics CFO in software.</h2>
              <p className="lead">
                Once the recovery engine is trusted, Recovra can expand into carrier analytics,
                contract monitoring, shipment intelligence, purchasing and supplier cost control.
              </p>
            </div>
            <div className="card">
              <h3>Expansion path</h3>
              <p>Freight audit → disputes → carrier analytics → rate negotiation → supplier invoices → purchasing → AI logistics CFO.</p>
              <Link href="/dashboard" className="btn btn-dark">Explore the demo</Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container">
          <strong>Recovra</strong> — Find overcharges. Recover savings. Control logistics.
        </div>
      </footer>
    </>
  );
}
