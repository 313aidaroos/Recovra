import { DashboardShell } from "@/components/DashboardShell";

export default function ContractsPage() {
  return (
    <DashboardShell active="contracts">
      <div className="page-head">
        <div>
          <h1>Contracts & rate sheets</h1>
          <div className="muted">The production app will normalize carrier agreements into auditable rate rules.</div>
        </div>
        <button className="btn btn-primary">Upload rate sheet</button>
      </div>

      <div className="grid-3">
        <div className="card">
          <div className="iconbox">N</div>
          <h3>Northline Freight</h3>
          <p>Demo rate agreement · effective through Dec 2026.</p>
        </div>
        <div className="card">
          <div className="iconbox">M</div>
          <h3>Metro LTL</h3>
          <p>Demo regional LTL rate sheet · review fuel schedule.</p>
        </div>
        <div className="card">
          <div className="iconbox">+</div>
          <h3>Add agreement</h3>
          <p>Production flow: private upload → extraction → normalized contract rules.</p>
        </div>
      </div>
    </DashboardShell>
  );
}
