import { DashboardShell } from "@/components/DashboardShell";

export default function RecoveriesPage() {
  return (
    <DashboardShell active="recoveries">
      <div className="page-head">
        <div>
          <h1>Recovery center</h1>
          <div className="muted">Track disputed and recovered freight charges.</div>
        </div>
      </div>

      <section className="panel">
        <div className="table-wrap">
          <table>
            <thead><tr><th>Invoice</th><th>Carrier</th><th>Disputed</th><th>Recovered</th><th>Status</th></tr></thead>
            <tbody>
              <tr><td>INV-10463</td><td>Northline Freight</td><td>$310</td><td>$310</td><td><span className="badge won">Won</span></td></tr>
              <tr><td>INV-10482</td><td>Northline Freight</td><td>$525</td><td>$0</td><td><span className="badge review">Draft</span></td></tr>
              <tr><td>INV-10477</td><td>Metro LTL</td><td>$184</td><td>$0</td><td><span className="badge open">Open</span></td></tr>
            </tbody>
          </table>
        </div>
      </section>
    </DashboardShell>
  );
}
