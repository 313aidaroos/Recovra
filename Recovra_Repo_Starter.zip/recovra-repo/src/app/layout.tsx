import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Recovra | Freight Cost Recovery",
  description: "Find overcharges. Recover savings. Control logistics."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
