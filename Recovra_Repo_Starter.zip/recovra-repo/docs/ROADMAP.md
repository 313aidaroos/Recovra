# Recovra Roadmap

## Phase 0 — included starter

- brand
- landing page
- dashboard
- demo audit flow
- deterministic savings calculation
- dispute draft
- Supabase production schema
- architecture docs
- Cursor implementation prompt

## Phase 1 — real accounts

- Supabase Auth
- organization onboarding
- membership/RLS verification
- protected dashboard
- settings

## Phase 2 — real documents

- private uploads
- PDF/image validation
- extraction adapter
- normalized invoice format
- normalized rate-sheet format
- review extracted data

## Phase 3 — production audits

- duplicate detection
- rate mismatch
- fuel mismatch
- accessorial validation
- weight-tier checks
- evidence links
- audit history
- manual override

## Phase 4 — recovery

- dispute editor
- email/export
- carrier response log
- recovered amount tracking
- recovery analytics

## Phase 5 — paid product

- plan limits
- Stripe
- usage
- customer support workflow
- audit exports

## Phase 6 — logistics intelligence

- carrier scorecards
- lane analytics
- contract renewal alerts
- spend anomalies
- AI logistics analyst

## Phase 7 — broader operating system

- purchasing
- supplier quote comparison
- supplier invoice audit
- purchase orders
- shipment monitoring
- claims
- AI logistics CFO

Rule: do not move to the next expansion layer until customers are getting measurable value from the previous one.
