# API Contracts

## GET /api/health

Response:

```json
{
  "ok": true,
  "app": "Recovra",
  "mode": "demo"
}
```

## POST /api/audit

Demo-only deterministic endpoint.

Request:

```json
{
  "carrier": "Northline Freight",
  "invoiceNumber": "INV-10482",
  "invoiceTotal": 4820,
  "expectedTotal": 4295,
  "duplicateDetention": 150,
  "questionableFuel": 117,
  "weightTierDifference": 258
}
```

Production version should receive normalized, trusted server-side data linked to authenticated organization records rather than trusting all customer-supplied totals.
