# Backend Architecture

## Goal

Keep the MVP cheap, understandable and auditable.

## Recommended architecture

```text
Browser
  |
  v
Next.js on Vercel
  |---- Auth/session ----> Supabase Auth
  |---- app data --------> Supabase Postgres
  |---- private docs ----> Supabase Storage
  |
  +---- server audit pipeline
         |
         +--> document extractor
         +--> normalizer
         +--> deterministic audit engine
         +--> optional AI explanation
         +--> audit findings persisted
```

## Why this architecture

- one web app
- one database
- one private document store
- server-side secrets
- inexpensive at small volume
- easy for Cursor to maintain
- avoids premature microservices

## Data flow

### Document upload

1. Authenticated user requests upload.
2. Server verifies organization membership.
3. Server generates an organization-scoped object path.
4. File is stored in a private bucket.
5. `documents` row is created.
6. Extraction begins.
7. Extracted JSON is stored.
8. Audit job links the relevant invoice, contract and shipment evidence.

### Audit

Audit engine receives normalized objects:

```ts
type NormalizedInvoice = {
  invoiceNumber: string;
  carrier: string;
  billedTotal: number;
  shipmentRef?: string;
  charges: Array<{
    code: string;
    label: string;
    amount: number;
  }>;
};
```

```ts
type NormalizedRate = {
  carrier: string;
  expectedTotal?: number;
  rules: Array<{
    code: string;
    expectedAmount?: number;
    permitted?: boolean;
  }>;
};
```

The engine should favor deterministic comparisons.

AI can:
- extract fields
- classify line items
- summarize evidence
- draft the dispute

AI should not:
- invent rates
- invent shipment facts
- silently decide unsupported contract terms
- claim a charge is legally invalid without evidence

## Suggested API routes

- `GET /api/health`
- `POST /api/audit`
- `POST /api/uploads/create`
- `POST /api/documents/:id/extract`
- `POST /api/audits/:id/run`
- `POST /api/audits/:id/dispute`
- `PATCH /api/disputes/:id`

Only the first two are included in the starter implementation. Cursor should add the rest in the order shown.

## Supabase notes

Use:
- publishable key in browser
- service role only on trusted server code if actually required
- RLS on exposed tables
- organization membership checks
- private Storage bucket
- signed URLs for temporary access

Do not store authorization roles in user-editable metadata.

## Background work

For an early MVP, extraction can happen inside a server request for small files.

As volume grows:
- create extraction jobs
- use a queue / durable worker
- make jobs idempotent
- save status and errors
- retry only retryable failures

## Extraction status

Suggested:
- uploaded
- extracting
- extracted
- needs_review
- failed

## Audit status

Suggested:
- draft
- processing
- review
- approved
- disputed
- closed

## Observability

Log:
- request id
- org id
- document id
- audit id
- extraction duration
- extraction provider/model
- confidence
- errors
- audit rule version

Never log raw secrets.
Avoid logging sensitive document contents.
