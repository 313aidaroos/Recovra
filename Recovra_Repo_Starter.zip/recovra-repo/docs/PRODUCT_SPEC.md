# Recovra Product Spec

## One-line definition

Recovra is a freight-cost recovery platform that compares transportation invoices against contracts and shipment evidence to identify possible overcharges and help businesses recover savings.

## Problem

Smaller companies often pay freight invoices without a dedicated audit team. Contracts, invoices, shipment documents, fuel schedules and accessorial rules are fragmented across PDFs, email and spreadsheets.

The result can include:

- duplicate invoices
- duplicate fees
- incorrect fuel surcharges
- wrong weight tiers
- incorrect contracted rates
- unsupported accessorials
- detention errors
- reclassification errors
- charges tied to the wrong shipment

## Core promise

**Upload your freight bills. Recovra shows you where money may have been overpaid and helps you recover it.**

## Target customer

Initial ICP:

- distributors
- wholesalers
- manufacturers
- import/export businesses
- building-material suppliers
- food distributors
- auto-parts distributors
- contractors with meaningful freight spend
- e-commerce businesses
- regional logistics operators

Best initial customer profile:

- 50–2,000 freight invoices/month
- no sophisticated internal audit team
- has rate sheets/contracts available
- wants savings without replacing its entire ERP/TMS

## MVP screens

### 1. Dashboard

Metrics:
- freight spend audited
- potential savings
- recovered savings
- recovery rate
- open disputes
- invoices audited

### 2. Audit Center

- upload invoice
- select/add contract
- attach shipment evidence
- audit
- review findings
- approve/reject findings

### 3. Audit Detail

Shows:
- carrier
- invoice number
- invoice total
- expected total
- potential overcharge
- confidence
- finding list
- evidence
- notes

### 4. Recovery Center

- create dispute
- edit dispute draft
- mark sent
- record response
- record recovered amount

### 5. Contracts

- upload rate sheet
- effective dates
- carrier
- normalized rate rules
- version history

### 6. Carriers / Analytics

- spend
- savings identified
- recovery performance
- top finding categories

## What Recovra is NOT in v1

Do not build:
- full dispatch
- ELD
- fleet GPS
- warehouse management
- driver payroll
- full TMS replacement
- freight brokerage marketplace

Those create complexity before product-market fit.

## Monetization

Possible subscription model:

- Free: 10 audits
- Starter: $49/mo
- Business: $149/mo
- Pro: $399/mo

Optional performance pricing:
- percentage of verified recovered savings

Before offering contingency/recovery arrangements broadly, confirm the commercial terms and any jurisdiction-specific legal requirements with qualified counsel.

## North-star metric

**Verified customer dollars recovered.**

Supporting metrics:
- dollars audited
- dollars identified
- recovery rate
- time to finding
- disputes won
- retention
