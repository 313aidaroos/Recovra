# CURSOR MASTER PROMPT — RECOVRA

You are the lead engineer finishing **Recovra**, a B2B freight-audit and logistics intelligence SaaS.

## Product identity

Brand: **Recovra**  
Tagline: **Find overcharges. Recover savings. Control logistics.**

Recovra helps a business detect freight/logistics invoice overcharges, quantify savings, prepare disputes, and eventually operate as an AI logistics CFO.

Do not turn this into a generic TMS. The initial product wedge is freight-cost recovery.

## Existing stack

- Next.js 16 App Router
- React 19
- TypeScript
- Supabase Postgres/Auth/Storage
- Vercel
- CSS kept in the repo to minimize dependencies
- Provider-agnostic AI/document extraction adapter to be added server-side

## Non-negotiable UX

A new customer should understand the product in under 30 seconds.

Primary user flow:

1. Sign in.
2. Create/select organization.
3. Upload freight invoice.
4. Upload or select applicable rate sheet / contract.
5. Optionally attach shipment/BOL/PO/proof-of-delivery.
6. Recovra extracts structured fields.
7. Audit engine compares billed charges to expected charges.
8. Results show:
   - invoice amount
   - expected amount
   - potential overcharge
   - confidence
   - itemized findings
   - evidence/source
9. User approves findings.
10. Recovra produces a dispute draft and tracks recovery status.
11. Dashboard shows identified savings, recovered savings and carrier trends.

## What is already in this repo

Read these files before changing architecture:

- README.md
- docs/PRODUCT_SPEC.md
- docs/BACKEND_ARCHITECTURE.md
- docs/SECURITY.md
- docs/ROADMAP.md
- supabase/migrations/0001_recovra.sql
- src/lib/audit-engine.ts

The demo mode must continue to work even if no external credentials exist.

## Phase 1 — make the repo production-ready

1. Run install and typecheck/build.
2. Fix any framework compatibility issues without redesigning the product.
3. Generate and commit the npm lockfile.
4. Implement Supabase SSR clients using current `@supabase/ssr`.
5. Add auth:
   - email/password or magic link
   - protected `/dashboard`
   - sign out
6. Create organization onboarding.
7. Never use user-editable metadata for authorization.
8. Keep RLS enabled on exposed tables.

## Phase 2 — document ingestion

Implement server-side ingestion for:

- carrier invoice PDF/image
- rate sheet / contract
- BOL
- purchase order
- shipment CSV

Pipeline:

`upload -> private storage -> document row -> extraction job -> normalized JSON -> audit engine -> audit + findings`

Requirements:

- validate MIME type and size
- generate private object keys
- never expose service-role keys
- save original file metadata
- save extraction confidence
- retain source references for every finding
- failed extraction must be retryable
- do not claim certainty when a field is ambiguous

## Phase 3 — AI extraction adapter

Create an interface similar to:

```ts
type ExtractionRequest = {
  documentType: "invoice" | "rate_sheet" | "bol" | "po";
  fileUrlOrBytes: unknown;
};

type ExtractionResult = {
  fields: Record<string, unknown>;
  confidence: number;
  warnings: string[];
};
```

The rest of the application must not depend directly on one AI vendor.

For invoices normalize at least:

- carrier
- invoice_number
- invoice_date
- shipment_id / PRO / BOL
- origin
- destination
- weight
- distance if present
- linehaul
- fuel surcharge
- detention
- liftgate
- residential
- lumper
- reclassification
- redelivery
- other accessorials
- taxes
- total

For rate sheets normalize:

- carrier
- effective dates
- lane/origin/destination
- service level
- base rate
- weight break
- fuel formula
- minimum charge
- permitted accessorials
- accessorial rates

## Phase 4 — audit rules

Keep deterministic rules as the source of truth whenever possible.

Flag:

- duplicate invoices
- duplicate accessorials
- billed total mismatch
- contract rate mismatch
- fuel surcharge mismatch
- weight tier mismatch
- unauthorized accessorial
- detention beyond contracted terms
- shipment document contradiction
- missing support for an accessorial
- possible duplicate shipment charge

Every finding needs:

- code
- title
- explanation
- expected value
- billed value
- potential savings
- confidence
- source/evidence
- review state

AI can explain a finding, but it must not silently invent contracted rates.

## Phase 5 — recovery center

Add dispute statuses:

`draft -> approved -> sent -> acknowledged -> won -> partially_won -> denied -> closed`

Generate a professional claim/dispute letter containing only supported facts.

Do not automatically send disputes until the account owner enables automation and chooses the relevant policy.

Track:

- amount disputed
- amount recovered
- date sent
- carrier response
- notes
- attachments

## Phase 6 — analytics

Dashboard cards:

- spend audited
- potential savings found
- savings recovered
- recovery rate
- open disputes
- average overcharge per invoice

Charts/tables:

- savings by carrier
- spend by carrier
- overcharge category
- recurring accessorials
- worst lanes
- monthly spend trend

## Phase 7 — monetization

Prepare plan gates but do not make billing block development.

Suggested plans:

- Free: first 10 audits
- Starter: $49/mo
- Business: $149/mo
- Pro: $399/mo
- Optional recovery model: percentage of verified recovered savings

Billing/legal language must make clear that findings may require customer review and are not guarantees of recovery.

## Long-term vision

After freight audit is working, Recovra expands into:

- carrier benchmarking
- RFQ / rate comparison
- shipment monitoring
- claims
- proof of delivery
- supplier invoice audit
- purchasing
- supplier quote comparison
- purchase orders
- contract monitoring
- inventory alerts
- AI logistics CFO / purchasing agent

Do not build those ahead of the audit/recovery loop.

## Definition of launchable MVP

Recovra is launchable when one real company can:

1. create an account,
2. create an organization,
3. upload an invoice and rate sheet,
4. receive structured audit findings,
5. review evidence,
6. generate a dispute,
7. update its status,
8. see identified/recovered savings on the dashboard,
9. use the app without any demo-only shortcuts.

When you finish a phase, run typecheck and build and list exactly what remains.
