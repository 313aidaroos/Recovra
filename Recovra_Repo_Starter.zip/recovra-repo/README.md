# Recovra

**Find overcharges. Recover savings. Control logistics.**

Recovra is a B2B freight-audit and logistics-intelligence platform for small and midsize distributors, wholesalers, importers, manufacturers, contractors, e-commerce businesses, and regional logistics operators.

The initial wedge is intentionally simple:

1. Upload or enter a freight invoice.
2. Add the contract/rate-sheet expectation.
3. Recovra compares billed vs expected.
4. It identifies possible overcharges.
5. It generates a recovery/dispute workflow.
6. The dashboard tracks money identified and recovered.

The long-term product becomes an AI logistics CFO that can monitor carrier spend, contracts, shipments, suppliers, disputes, claims, and purchasing.

## Run the demo

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`.

The repo boots in **demo mode**. You can use the audit calculator without Supabase or AI keys.

## What works immediately

- Marketing homepage
- Recovra branded dashboard
- Demo freight audit workflow
- Overcharge calculation
- Example audit findings
- Recovery/dispute drafting
- API health endpoint
- Production Supabase schema + RLS migration
- Production backend architecture
- Cursor implementation plan

## Production activation order

1. Create Supabase project.
2. Run `supabase/migrations/0001_recovra.sql` in a development database.
3. Create the private `recovra-documents` Storage bucket and add storage policies.
4. Add Supabase credentials to `.env.local`.
5. Implement Auth SSR and route protection.
6. Replace the demo audit parser with the document extraction adapter described in `docs/BACKEND_ARCHITECTURE.md`.
7. Add structured AI extraction for invoices, BOLs and rate sheets.
8. Add email delivery for dispute letters.
9. Add Stripe only after the core audit loop is verified.

## Important files

- `CURSOR_MASTER_PROMPT.md` — paste into Cursor Agent with the repo open.
- `docs/PRODUCT_SPEC.md` — product definition and scope.
- `docs/BACKEND_ARCHITECTURE.md` — production data flow.
- `docs/ROADMAP.md` — build phases.
- `docs/SECURITY.md` — non-negotiable security rules.
- `supabase/migrations/0001_recovra.sql` — core database.
- `src/lib/audit-engine.ts` — deterministic audit logic.
- `src/app/api/audit/route.ts` — demo audit API.
- `src/app/dashboard/page.tsx` — dashboard.

## Brand

**Recovra**  
**Find overcharges. Recover savings. Control logistics.**

The generated logo is stored in `public/recovra-logo.png`.
