# Supabase setup

1. Create a development Supabase project.
2. Use the current Supabase CLI or dashboard SQL editor to apply the schema.
3. Run database/security advisors before promoting changes.
4. Create a private Storage bucket named `recovra-documents`.
5. Add Storage policies that verify organization membership before upload/read.
6. Put only the publishable key in `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
7. Keep the service-role key server-side.

The SQL file intentionally does **not** make the Storage bucket public.

Important onboarding note:
Creating an organization and its owner membership should be one trusted transaction/RPC. Do not add a permissive membership policy just to simplify onboarding.
