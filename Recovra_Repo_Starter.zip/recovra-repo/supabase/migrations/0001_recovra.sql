-- Recovra core schema
-- Apply in a development Supabase project, review advisors, then promote through normal migration workflow.

create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','analyst','viewer')),
  created_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  uploaded_by uuid not null references auth.users(id) on delete restrict,
  document_type text not null check (document_type in ('invoice','rate_sheet','bol','po','pod','other')),
  storage_path text not null,
  original_filename text not null,
  mime_type text,
  size_bytes bigint,
  status text not null default 'uploaded' check (status in ('uploaded','extracting','extracted','needs_review','failed')),
  extracted_json jsonb,
  extraction_confidence numeric(5,4),
  extraction_warnings jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.contracts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  carrier_name text not null,
  document_id uuid references public.documents(id) on delete set null,
  effective_from date,
  effective_to date,
  normalized_rules jsonb not null default '{}'::jsonb,
  status text not null default 'active' check (status in ('draft','active','expired','archived')),
  created_at timestamptz not null default now()
);

create table if not exists public.audits (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  invoice_document_id uuid references public.documents(id) on delete set null,
  contract_id uuid references public.contracts(id) on delete set null,
  carrier_name text,
  invoice_number text,
  invoice_total numeric(14,2) not null default 0,
  expected_total numeric(14,2) not null default 0,
  potential_overcharge numeric(14,2) not null default 0,
  status text not null default 'draft' check (status in ('draft','processing','review','approved','disputed','closed')),
  audit_rule_version text not null default 'v1',
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.audit_findings (
  id uuid primary key default gen_random_uuid(),
  audit_id uuid not null references public.audits(id) on delete cascade,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text not null,
  title text not null,
  explanation text not null,
  billed_value jsonb,
  expected_value jsonb,
  potential_savings numeric(14,2) not null default 0,
  confidence numeric(5,4),
  evidence jsonb not null default '[]'::jsonb,
  review_state text not null default 'pending' check (review_state in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.disputes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  audit_id uuid not null references public.audits(id) on delete cascade,
  amount_disputed numeric(14,2) not null default 0,
  amount_recovered numeric(14,2) not null default 0,
  status text not null default 'draft' check (status in ('draft','approved','sent','acknowledged','won','partially_won','denied','closed')),
  draft_text text,
  sent_at timestamptz,
  carrier_response text,
  approved_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Helpful indexes
create index if not exists documents_org_idx on public.documents(organization_id);
create index if not exists contracts_org_idx on public.contracts(organization_id);
create index if not exists audits_org_idx on public.audits(organization_id);
create index if not exists audits_invoice_idx on public.audits(organization_id, invoice_number);
create index if not exists audit_findings_org_idx on public.audit_findings(organization_id);
create index if not exists disputes_org_idx on public.disputes(organization_id);

-- RLS
alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.documents enable row level security;
alter table public.contracts enable row level security;
alter table public.audits enable row level security;
alter table public.audit_findings enable row level security;
alter table public.disputes enable row level security;

-- Organizations
create policy "members can view organizations"
on public.organizations for select
to authenticated
using (
  exists (
    select 1
    from public.organization_members m
    where m.organization_id = organizations.id
      and m.user_id = (select auth.uid())
  )
);

create policy "authenticated users can create organizations"
on public.organizations for insert
to authenticated
with check (created_by = (select auth.uid()));

-- Membership
create policy "members can view membership"
on public.organization_members for select
to authenticated
using (
  exists (
    select 1
    from public.organization_members self_m
    where self_m.organization_id = organization_members.organization_id
      and self_m.user_id = (select auth.uid())
  )
);

-- Org scoped tables: select
create policy "members can view documents"
on public.documents for select to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = documents.organization_id and m.user_id = (select auth.uid())
));

create policy "members can view contracts"
on public.contracts for select to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = contracts.organization_id and m.user_id = (select auth.uid())
));

create policy "members can view audits"
on public.audits for select to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = audits.organization_id and m.user_id = (select auth.uid())
));

create policy "members can view findings"
on public.audit_findings for select to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = audit_findings.organization_id and m.user_id = (select auth.uid())
));

create policy "members can view disputes"
on public.disputes for select to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = disputes.organization_id and m.user_id = (select auth.uid())
));

-- Insert/update policies: owner/admin/analyst can operate on org records.
create policy "operators can insert documents"
on public.documents for insert to authenticated
with check (
  uploaded_by = (select auth.uid())
  and exists (
    select 1 from public.organization_members m
    where m.organization_id = documents.organization_id
      and m.user_id = (select auth.uid())
      and m.role in ('owner','admin','analyst')
  )
);

create policy "operators can update documents"
on public.documents for update to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = documents.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
))
with check (exists (
  select 1 from public.organization_members m
  where m.organization_id = documents.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
));

create policy "operators can insert audits"
on public.audits for insert to authenticated
with check (
  created_by = (select auth.uid())
  and exists (
    select 1 from public.organization_members m
    where m.organization_id = audits.organization_id
      and m.user_id = (select auth.uid())
      and m.role in ('owner','admin','analyst')
  )
);

create policy "operators can update audits"
on public.audits for update to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = audits.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
))
with check (exists (
  select 1 from public.organization_members m
  where m.organization_id = audits.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
));

create policy "operators can insert findings"
on public.audit_findings for insert to authenticated
with check (exists (
  select 1 from public.organization_members m
  where m.organization_id = audit_findings.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
));

create policy "operators can update findings"
on public.audit_findings for update to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = audit_findings.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
))
with check (exists (
  select 1 from public.organization_members m
  where m.organization_id = audit_findings.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
));

create policy "operators can insert disputes"
on public.disputes for insert to authenticated
with check (exists (
  select 1 from public.organization_members m
  where m.organization_id = disputes.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
));

create policy "operators can update disputes"
on public.disputes for update to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = disputes.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
))
with check (exists (
  select 1 from public.organization_members m
  where m.organization_id = disputes.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin','analyst')
));

create policy "admins can insert contracts"
on public.contracts for insert to authenticated
with check (exists (
  select 1 from public.organization_members m
  where m.organization_id = contracts.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin')
));

create policy "admins can update contracts"
on public.contracts for update to authenticated
using (exists (
  select 1 from public.organization_members m
  where m.organization_id = contracts.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin')
))
with check (exists (
  select 1 from public.organization_members m
  where m.organization_id = contracts.organization_id
    and m.user_id = (select auth.uid())
    and m.role in ('owner','admin')
));

-- IMPORTANT:
-- Organization creation also needs an owner membership row.
-- Implement that in a trusted server transaction / RPC after auth is wired.
-- Do not weaken RLS to make onboarding easier.
